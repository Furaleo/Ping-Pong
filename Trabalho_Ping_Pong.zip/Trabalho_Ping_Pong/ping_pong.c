/*
Jogo de Ping Pong em C - Terminal (Windows/Linux)
--------------------------------------------------

Descrição do Algoritmo:
Este é um jogo de ping pong em C, com movimentação de bola, colisões com raquete, rede e uso de habilidades. O jogador usa o teclado para controlar a raquete. O adversário é um computador com dificuldade configurável. A bola acelera ou desacelera conforme a parte da raquete atingida. Habilidades aparecem em locais aleatórios e alteram o comportamento do jogo. O jogo é vencido ao atingir um número de sets definido no menu.

Este jogo segue restrições acadêmicas:
- Sem uso de orientação a objetos.
- Sem bibliotecas gráficas ou externas.
- Usa apenas: I/O, structs, matrizes, if, for, while, switch e recursos padrão da linguagem C.

Compilação:
gcc ping_pong.c -o ping_pong.exe

Execução:
Clique no executável ou rode no terminal:
./ping_pong.exe   (Linux) ou ping_pong.exe (Windows)

Controles durante o jogo:
- W = mover a raquete para cima
- S = mover a raquete para baixo
- Q = sair do jogo
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifdef _WIN32
  #include <conio.h>
  #include <windows.h>
#else
  #include <unistd.h>
  #include <termios.h>
  #include <fcntl.h>
#endif

#define WIDTH 40
#define HEIGHT 20
#define PADDLE_HEIGHT 4
#define PLAYER_PADDLE_X 1
#define COMPUTER_PADDLE_X (WIDTH - 2)
#define MAX_BALLS 50
#define NUM_ABILITIES 3
#define NET_COLUMN (WIDTH/2)

int baseDelay;
int currentDelay;

typedef struct {
    int x, y;
    int dx, dy;
    int lastTouched;
    int prev_x, prev_y;
    int waitTicks; // NOVO: atraso inicial após saque
} Ball;

typedef struct {
    int y;
} Paddle;

typedef struct {
    int x, y;
    char type;
    int active;
} Ability;

int scorePlayer = 0, scoreComputer = 0;
int setsPlayer = 0, setsComputer = 0;

int adversarySkill;
int targetSets;
int pointsPerSet;
int abilityFrequency;

Ball balls[MAX_BALLS];
int numBalls = 1;
Ability abilities[NUM_ABILITIES];

time_t lastAbilitySpawn;

#ifdef _WIN32
__attribute__((constructor))
void enableVTMode() {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD dwMode = 0;
    if (GetConsoleMode(hOut, &dwMode))
        SetConsoleMode(hOut, dwMode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
}
#else
void initTermios(int echo) {
    struct termios newt;
    tcgetattr(STDIN_FILENO, &newt);
    newt.c_lflag &= ~ICANON;
    if (!echo)
        newt.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}
void resetTermios(void) {
    struct termios newt;
    tcgetattr(STDIN_FILENO, &newt);
    newt.c_lflag |= ICANON | ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}
int kbhit(void) {
    struct termios oldt, newt;
    int ch, oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if (ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}
int getch(void) {
    int ch;
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    return ch;
}
#endif

// (Para simplificação, funções auxiliares e lógica principal continuam nos próximos passos)
