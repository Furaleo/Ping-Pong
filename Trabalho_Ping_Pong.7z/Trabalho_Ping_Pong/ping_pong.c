/*
Jogo de Ping Pong em C

Menu:
  - Velocidade base do jogo (delay em ms, ex: 200)
  - Dificuldade do adversario (1 a 10, 10 = adversario quase perfeito)
  - Numero de sets para vencer e pontos por set
  - Frequencia de aparicao das habilidades (em segundos)

Regras adicionais:
  - A raquete tem 4 segmentos. Se a bola colidir:
      * Nos segmentos 1 ou 2 (meio): trajetoria reta (dy = 0) e currentDelay diminui em 50 ms (min = 50ms).
      * Nos segmentos 0 ou 3 (ponta): velocidade "reduz" (delay aumenta 50 ms) ate o valor base.
  - Uma rede eh desenhada no centro. Quando a bola cruza a rede:
      * Se o ultimo toque foi do jogador, chance de fault aumenta com dificuldade.
      * Se foi do computador, chance eh complementar.
      * Em caso de fault, o adversario marca ponto e ganha o saque.
  - A bola surge na raquete do servidor (aleatoriamente no inicio, ou quem marcou ponto).

Controles:
  - Jogador: W = subir, S = descer, Q = sair.

Compilacao:
  1. Clique duas vezes no executavel "teste.exe".
  2. Use um compilador online (ex: gdb online) e cole o codigo.
  3. No VS Code, abra a pasta, edite e execute com gcc.

* O jogo continua rodando ate o jogador apertar Q (Sair).
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifdef _WIN32
  #include <conio.h>
  #include <windows.h>
#else
  #include <unistd.h>
  #include <termios.h>
  #include <fcntl.h>
#endif

// Construtor para habilitar o modo VT automaticamente no Windows
#ifdef _WIN32
__attribute__((constructor))
void enableVTMode() {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut == INVALID_HANDLE_VALUE) {
        fprintf(stderr, "Erro ao obter o handle do console.\n");
        return;
    }
    DWORD dwMode = 0;
    if (!GetConsoleMode(hOut, &dwMode)) {
        fprintf(stderr, "Erro ao obter o modo do console.\n");
        return;
    }
    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    if (!SetConsoleMode(hOut, dwMode)) {
        fprintf(stderr, "Erro ao configurar o modo VT do console.\n");
        return;
    }
}
#endif

#define WIDTH 40         // Largura da area interna
#define HEIGHT 20        // Altura da area interna
#define PADDLE_HEIGHT 4  // Altura das raquetes
#define PLAYER_PADDLE_X 1
#define COMPUTER_PADDLE_X (WIDTH - 2)
#define MAX_BALLS 50     // Maximo de bolas (power-up '*')
#define NUM_ABILITIES 3  // Numero de habilidades
#define NET_COLUMN (WIDTH/2)  // Coluna da rede

// Variaveis de velocidade
int baseDelay;      // Delay base escolhido no menu
int currentDelay;   // Delay atual (varia conforme os golpes)

// Estruturas
typedef struct {
    int x, y;         // Posicao interna
    int dx, dy;       // Direcao
    int lastTouched;  // 0: nenhum, 1: jogador, 2: computador
    int prev_x, prev_y; // Para apagar a posicao anterior
} Ball;

typedef struct {
    int y; // Posicao vertical da raquete
} Paddle;

typedef struct {
    int x, y;       // Posicao da habilidade
    char type;      // '+', '-' ou '*'
    int active;     // 1 se ativa
} Ability;
// Placar e sets
int scorePlayer = 0, scoreComputer = 0;
int setsPlayer = 0, setsComputer = 0;

// Parametros do menu
int adversarySkill;   // 1 a 10
int targetSets;
int pointsPerSet;
int abilityFrequency; // em segundos

// Vetores para bolas e habilidades
Ball balls[MAX_BALLS];
int numBalls = 1;
Ability abilities[NUM_ABILITIES];

// Controle de tempo para habilidades
time_t lastAbilitySpawn;

#ifndef _WIN32
// Funcoes para terminal Unix-like
void initTermios(int echo) {
    struct termios newt;
    tcgetattr(STDIN_FILENO, &newt);
    newt.c_lflag &= ~ICANON;
    if (!echo)
      newt.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}
void resetTermios(void) {
    struct termios newt;
    tcgetattr(STDIN_FILENO, &newt);
    newt.c_lflag |= ICANON | ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}
int kbhit(void) {
    struct termios oldt, newt;
    int ch, oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if(ch != EOF) {
      ungetc(ch, stdin);
      return 1;
    }
    return 0;
}
int getch(void) {
    int ch;
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    return ch;
}
#endif

// Posiciona o cursor usando sequencias ANSI
void gotoxy(int row, int col) {
    printf("\033[%d;%dH", row, col);
}

// Desenha o quadro estatico: bordas, rede e instrucoes
void drawStaticBoard() {
    int i, j;
    printf("\033[2J\033[H"); // Limpa a tela
    for(i = 0; i < WIDTH + 2; i++)
      printf("#");
    printf("\n");
    for(j = 0; j < HEIGHT; j++){
      printf("#");
      for(i = 0; i < WIDTH; i++){
          if(i == NET_COLUMN && (j % 2 == 0))
              printf("|");
          else
              printf(" ");
      }
      printf("#\n");
    }
    for(i = 0; i < WIDTH + 2; i++)
      printf("#");
    printf("\n");
    printf("Controles: W = subir, S = descer, Q = sair\n");
}

// Atualiza o placar (sets e pontos)
void updateScoreBoard() {
    gotoxy(HEIGHT + 3, 1);
    printf("Sets -> Jogador: %d   Computador: %d    |    Pontos -> Jogador: %d   Computador: %d    ", 
           setsPlayer, setsComputer, scorePlayer, scoreComputer);
}
// Funcao para gerar uma habilidade aleatoria
void spawnAbility(Ability *ab) {
    ab->x = 2 + rand() % (WIDTH - 4);
    ab->y = 1 + rand() % (HEIGHT - 2);
    int r = rand() % 3;
    if(r == 0)
        ab->type = '+';
    else if(r == 1)
        ab->type = '-';
    else
        ab->type = '*';
    ab->active = 1;
}

// Inicializa as habilidades
void initAbilities() {
    int i;
    for(i = 0; i < NUM_ABILITIES; i++){
        spawnAbility(&abilities[i]);
    }
    lastAbilitySpawn = time(NULL);
}

// Desenha as habilidades ativas
void drawAbilities() {
    int i;
    for(i = 0; i < NUM_ABILITIES; i++){
        if(abilities[i].active){
            gotoxy(abilities[i].y + 2, abilities[i].x + 2);
            printf("%c", abilities[i].type);
        }
    }
}

// Aplica o efeito de uma habilidade
void applyAbility(Ball *ball, Ability *ab) {
    if(ball->lastTouched != 1)
        return;

    if(ab->type == '+'){
        if(currentDelay > 50)
            currentDelay = (currentDelay - 20 < 50) ? 50 : currentDelay - 20;
    } else if(ab->type == '-'){
        if(currentDelay < baseDelay)
            currentDelay = (currentDelay + 20 > baseDelay) ? baseDelay : currentDelay + 20;
    } else if(ab->type == '*'){
        int factor = 2 + rand() % 4; // entre 2 e 5
        int newBalls = factor - 1;
        int i;
        for(i = 0; i < newBalls && numBalls < MAX_BALLS; i++){
            balls[numBalls].x = ball->x;
            balls[numBalls].y = ball->y;
            balls[numBalls].dx = (rand() % 2 == 0) ? 1 : -1;
            balls[numBalls].dy = (rand() % 2 == 0) ? 1 : -1;
            balls[numBalls].lastTouched = ball->lastTouched;
            balls[numBalls].prev_x = ball->x;
            balls[numBalls].prev_y = ball->y;
            numBalls++;
        }
    }

    spawnAbility(ab);
}

// Spawn da bola apos ponto, com direcao inicial
void spawnBall(int server, Paddle *player, Paddle *computer) {
    numBalls = 1;
    Ball *b = &balls[0];

    if(server == 1){
        b->x = 3;
        b->y = player->y + PADDLE_HEIGHT / 2;
        b->dx = 1;
    } else {
        b->x = WIDTH - 4;
        b->y = computer->y + PADDLE_HEIGHT / 2;
        b->dx = -1;
    }

    int r = rand() % 3;
    b->dy = r - 1;

    b->lastTouched = 0;
    b->prev_x = b->x;
    b->prev_y = b->y;

    currentDelay = baseDelay;
}

// Colisao com a rede
void checkNetCollision(Ball *ball, Paddle *player, Paddle *computer) {
    if((ball->prev_x < NET_COLUMN && ball->x >= NET_COLUMN) ||
       (ball->prev_x > NET_COLUMN && ball->x <= NET_COLUMN)){
        double prob;

        if(ball->lastTouched == 1)
            prob = 10.0 + (adversarySkill - 1) * 8.0;
        else if(ball->lastTouched == 2)
            prob = 100.0 - (10.0 + (adversarySkill - 1) * 8.0);
        else
            return;

        double roll = (rand() % 10000) / 100.0;
        if(roll < prob){
            if(ball->lastTouched == 1){
                scoreComputer++;
                spawnBall(2, player, computer);
            } else {
                scorePlayer++;
                spawnBall(1, player, computer);
            }
        }
    }
}
int main() {
    int i, j;
    Paddle player, computer;
    int prev_player_y, prev_computer_y;

    // Menu inicial
    printf("Bem-vindo ao Ping Pong!\n");
    printf("Digite a velocidade base do jogo (delay em ms, ex: 200): ");
    scanf("%d", &baseDelay);
    currentDelay = baseDelay;
    printf("Digite a dificuldade do adversario (1 a 10, 10 = adversario perfeito): ");
    scanf("%d", &adversarySkill);
    printf("Digite o numero de sets para vencer: ");
    scanf("%d", &targetSets);
    printf("Digite a pontuacao necessaria para vencer cada set: ");
    scanf("%d", &pointsPerSet);
    printf("Digite a frequencia de aparicao das habilidades (em segundos, ex: 5): ");
    scanf("%d", &abilityFrequency);

    srand(time(NULL));

    // Inicializa as raquetes
    player.y = HEIGHT / 2 - PADDLE_HEIGHT / 2;
    computer.y = HEIGHT / 2 - PADDLE_HEIGHT / 2;
    prev_player_y = player.y;
    prev_computer_y = computer.y;

    // Define servidor inicial
    int server = (rand() % 2) + 1;
    spawnBall(server, &player, &computer);

    // Inicializa habilidades
    initAbilities();

#ifndef _WIN32
    initTermios(0);
#endif

    drawStaticBoard();
    updateScoreBoard();
    drawAbilities();
    for(i = 0; i < PADDLE_HEIGHT; i++){
        gotoxy(player.y + i + 2, PLAYER_PADDLE_X + 2);
        printf("|");
        gotoxy(computer.y + i + 2, COMPUTER_PADDLE_X + 2);
        printf("|");
    }
    for(i = 0; i < numBalls; i++){
        gotoxy(balls[i].y + 2, balls[i].x + 2);
        printf("O");
    }
    fflush(stdout);

    // Loop principal
    while(setsPlayer < targetSets && setsComputer < targetSets) {
#ifdef _WIN32
        if(kbhit()){
            char ch = getch();
            if(ch == 'w' || ch == 'W'){
                if(player.y > 0)
                    player.y--;
            } else if(ch == 's' || ch == 'S'){
                if(player.y + PADDLE_HEIGHT < HEIGHT)
                    player.y++;
            } else if(ch == 'q' || ch == 'Q'){
                break;
            }
        }
#else
        if(kbhit()){
            int ch = getch();
            if(ch == 'w' || ch == 'W'){
                if(player.y > 0)
                    player.y--;
            } else if(ch == 's' || ch == 'S'){
                if(player.y + PADDLE_HEIGHT < HEIGHT)
                    player.y++;
            } else if(ch == 'q' || ch == 'Q'){
                break;
            }
        }
#endif
        // Apaga posicoes anteriores
        for(i = 0; i < numBalls; i++){
            gotoxy(balls[i].prev_y + 2, balls[i].prev_x + 2);
            printf(" ");
        }
        for(j = 0; j < PADDLE_HEIGHT; j++){
            gotoxy(prev_player_y + j + 2, PLAYER_PADDLE_X + 2);
            printf(" ");
            gotoxy(prev_computer_y + j + 2, COMPUTER_PADDLE_X + 2);
            printf(" ");
        }

        // Atualiza as bolas
        for(i = 0; i < numBalls; i++){
            balls[i].x += balls[i].dx;
            balls[i].y += balls[i].dy;

            if(balls[i].y <= 0 || balls[i].y >= HEIGHT - 1)
                balls[i].dy = -balls[i].dy;

            checkNetCollision(&balls[i], &player, &computer);

            // Colisão com jogador
            if(balls[i].x == 2){
                if(balls[i].y >= player.y && balls[i].y < player.y + PADDLE_HEIGHT){
                    int segment = balls[i].y - player.y;
                    if(segment == 1 || segment == 2){
                        balls[i].dy = 0;
                        if(currentDelay > 50)
                            currentDelay = (currentDelay - 50 < 50) ? 50 : currentDelay - 50;
                    } else {
                        if(currentDelay < baseDelay)
                            currentDelay = (currentDelay + 50 > baseDelay) ? baseDelay : currentDelay + 50;
                    }
                    balls[i].dx = -balls[i].dx;
                    balls[i].lastTouched = 1;
                }
            }

            // Colisão com computador
            if(balls[i].x == WIDTH - 3){
                if(balls[i].y >= computer.y && balls[i].y < computer.y + PADDLE_HEIGHT){
                    int segment = balls[i].y - computer.y;
                    if(segment == 1 || segment == 2){
                        balls[i].dy = 0;
                        if(currentDelay > 50)
                            currentDelay = (currentDelay - 50 < 50) ? 50 : currentDelay - 50;
                    } else {
                        if(currentDelay < baseDelay)
                            currentDelay = (currentDelay + 50 > baseDelay) ? baseDelay : currentDelay + 50;
                    }
                    balls[i].dx = -balls[i].dx;
                    balls[i].lastTouched = 2;
                }
            }

            // Pontuação
            if(balls[i].x <= 0){
                scoreComputer++;
                spawnBall(2, &player, &computer);
                continue;
            } else if(balls[i].x >= WIDTH - 1){
                scorePlayer++;
                spawnBall(1, &player, &computer);
                continue;
            }

            // Habilidades
            for(j = 0; j < NUM_ABILITIES; j++){
                if(abilities[j].active && balls[i].x == abilities[j].x && balls[i].y == abilities[j].y)
                    applyAbility(&balls[i], &abilities[j]);
            }

            balls[i].prev_x = balls[i].x;
            balls[i].prev_y = balls[i].y;
        }

        // Movimento do computador
        if(computer.y + PADDLE_HEIGHT / 2 < balls[0].y){
            if(computer.y + PADDLE_HEIGHT < HEIGHT)
                computer.y++;
        } else if(computer.y + PADDLE_HEIGHT / 2 > balls[0].y){
            if(computer.y > 0)
                computer.y--;
        }

        // Desenha objetos
        for(i = 0; i < numBalls; i++){
            gotoxy(balls[i].y + 2, balls[i].x + 2);
            printf("O");
        }
        for(j = 0; j < PADDLE_HEIGHT; j++){
            gotoxy(player.y + j + 2, PLAYER_PADDLE_X + 2);
            printf("|");
            gotoxy(computer.y + j + 2, COMPUTER_PADDLE_X + 2);
            printf("|");
        }

        drawAbilities();

        for(i = 0; i < HEIGHT; i++){
            gotoxy(i + 2, NET_COLUMN + 2);
            if(i % 2 == 0)
                printf("|");
        }

        updateScoreBoard();
        fflush(stdout);

#ifdef _WIN32
        Sleep(currentDelay);
#else
        usleep(currentDelay * 1000);
#endif

        prev_player_y = player.y;
        prev_computer_y = computer.y;

        // Atualiza habilidades
        if(difftime(time(NULL), lastAbilitySpawn) >= abilityFrequency){
            for(i = 0; i < NUM_ABILITIES; i++)
                spawnAbility(&abilities[i]);
            lastAbilitySpawn = time(NULL);
        }

        // Fim do set
        if(scorePlayer >= pointsPerSet){
            setsPlayer++;
            scorePlayer = 0;
            scoreComputer = 0;
            gotoxy(HEIGHT + 4, 1);
            printf("Set ganho pelo Jogador!                ");
            fflush(stdout);
#ifdef _WIN32
            Sleep(1000);
#else
            usleep(1000000);
#endif
        } else if(scoreComputer >= pointsPerSet){
            setsComputer++;
            scorePlayer = 0;
            scoreComputer = 0;
            gotoxy(HEIGHT + 4, 1);
            printf("Set ganho pelo Computador!             ");
            fflush(stdout);
#ifdef _WIN32
            Sleep(1000);
#else
            usleep(1000000);
#endif
        }
    }

#ifndef _WIN32
    resetTermios();
#endif

    gotoxy(HEIGHT + 6, 1);
    if(setsPlayer >= targetSets)
        printf("Parabens! Voce venceu o jogo! Sets: %d x %d\n", setsPlayer, setsComputer);
    else if(setsComputer >= targetSets)
        printf("O Computador venceu o jogo! Sets: %d x %d\n", setsPlayer, setsComputer);
    else
        printf("Jogo encerrado pelo jogador.\n");

    return 0;
}
